Notice:
Parts of the images were gathered from literatures, others were collected by the authors.

All the images can only be used in research. None of them can be used for commercial purpose.

The following reference should be cited if you use these images in your research or publish papers.

Yundong Li, Hongguang Li,and Hongren Wang. Pixel-wise Crack Detection Using Deep Local Pattern Predictor for Robot Application, Sensor